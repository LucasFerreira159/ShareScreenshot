package com.app4funbr.screenshot

import android.graphics.Bitmap
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.app4funbr.screenshot.extensions.requestPermissions

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val isAccept = requestPermissions()

        /*if(isAccept) {
            Instacapture.capture(this, object : SimpleScreenCapturingListener() {
                override fun onCaptureComplete(bitmap: Bitmap) {
                    //Your code here..

                }
            })
        }*/
    }
}
